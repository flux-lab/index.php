from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from telegram import Update
from checker import bulk_cek_nawala, bulk_cek_nawala_with_info, cek_nawala_by_group
import re, os, asyncio, requests, json, time
from urllib.parse import urlparse, urlunparse
from utils import (
    read_list, write_list, read_json, write_json,
    load_domains_data, save_domains_data, add_domain, remove_domain,
    get_all_domains, get_domain_info, get_domains_by_group,
    get_groups_sorted, add_group, remove_group, set_group_priority,
    get_domains_ordered_by_priority,
    # Stok group functions
    load_stok_data, save_stok_data,
    stok_add_group, stok_remove_group, stok_list_groups,
    stok_add_domains, stok_remove_domain, stok_get_domains,
    stok_ambil, stok_peek, stok_peek_all, stok_return_domain,
    migrate_stok_txt_to_json
)

# =========================
# 1. KONFIGURASI
# =========================

DOMAINS_FILE = "domains_data.json"
STOK_FILE = "stok.txt"          # Legacy, for migration only
STOK_DATA_FILE = "stok_data.json"  # NEW: grouped stok
GRUP_FILE = "grup.txt"
LINKS_FILE = "active_links.json"

# --- TOKEN TELEGRAM ---
TOKEN = "8787553035:AAHNq_Mv-m3O2FvDlnnQjOu482PPgf6lwSA"

# --- SETTING HOSTING ---
API_SHORTLINK_URL = "https://ayubersamakita.xyz/api.php" 
API_SHORTLINK_KEY = "perguso21"

# =========================
# 2. HELPER (FILE & DATABASE)
# =========================

def load_links():
    return read_json(LINKS_FILE, {})

def save_links(data):
    write_json(LINKS_FILE, data)

def update_link_local(nama, url_asli, short_url, stok_group="default"):
    """Save link with stok group info"""
    data = load_links()
    data[nama] = {"url": url_asli, "short": short_url, "stok": stok_group}
    save_links(data)

def delete_link_local(nama):
    """Delete a link from local database"""
    data = load_links()
    if nama in data:
        del data[nama]
        save_links(data)
        return True
    return False

def norm_domain(d: str) -> str:
    """Normalize domain - extract clean domain from URL or domain string"""
    if not d: 
        return ""
    d = d.strip().lower()
    d = re.sub(r"^https?://", "", d)
    d = re.sub(r"^www\.", "", d)
    d = d.split('/')[0]
    d = d.split('?')[0]
    d = d.split('#')[0]
    return d

def get_domain_from_url(url: str) -> str:
    """Extract domain from full URL"""
    try:
        parsed = urlparse(url)
        domain = parsed.netloc.lower()
        domain = re.sub(r"^www\.", "", domain)
        return domain
    except:
        return norm_domain(url)

def get_links_by_domain(target_domain: str) -> list:
    """
    Find all shortlinks that use a specific domain
    Returns: [(nama, info), ...]
    """
    data = load_links()
    found = []
    target_clean = norm_domain(target_domain)
    
    for nama, info in data.items():
        url = info.get("url", "")
        url_domain = get_domain_from_url(url)
        
        if url_domain == target_clean or url_domain.endswith("." + target_clean):
            found.append((nama, info))
    
    return found

# --- STOK HELPER (backward compat wrappers) ---
def add_to_list(file, item):
    items = read_list(file)
    if item not in items:
        items.append(item)
        write_list(file, items)
        return True
    return False

def delete_from_list(file, item):
    items = read_list(file)
    if item in items:
        items.remove(item)
        write_list(file, items)
        return True
    return False

def add_grup(chat_id): 
    add_to_list(GRUP_FILE, str(chat_id))

def is_url(text: str) -> bool:
    """Check if text looks like a URL (has http, dots with TLD, slashes)"""
    t = text.strip().lower()
    if t.startswith("http://") or t.startswith("https://"):
        return True
    # Has domain-like pattern: something.tld/...
    if re.match(r'^[a-z0-9\-]+\.[a-z]{2,}', t) and ('/' in t or '?' in t or '.' in t):
        return True
    return False

def parse_create_args(args):
    """
    Smart parse: auto-detect which arg is URL and which is nama.
    Supports both:
      /create [url] [nama] [stok]
      /create [nama] [url] [stok]
    Returns: (url, nama, stok_group)
    """
    if len(args) < 2:
        return None, None, "default"
    
    arg1 = args[0].strip()
    arg2 = args[1].strip()
    stok_group = args[2].strip().lower() if len(args) > 2 else "default"
    
    # Detect which is URL
    if is_url(arg1) and not is_url(arg2):
        url_raw = arg1
        nama = arg2
    elif is_url(arg2) and not is_url(arg1):
        url_raw = arg2
        nama = arg1
    elif is_url(arg1):
        # Both look like URLs, first one is URL
        url_raw = arg1
        nama = arg2
    else:
        # Neither looks like URL, assume first=url second=nama (legacy)
        url_raw = arg1
        nama = arg2
    
    # Clean nama
    nama = re.sub(r'[^a-zA-Z0-9_-]', '', nama)
    
    # Ensure URL has protocol
    if not url_raw.startswith("http"):
        url_raw = "https://" + url_raw
    
    return url_raw, nama, stok_group

def get_kode_from_shortlink(short_url):
    return short_url.strip().split("/")[-1]

def ganti_domain_keep_path(full_url_lama, domain_stok_baru):
    """Replace domain in URL but keep path, query, fragment"""
    domain_clean = re.sub(r"^https?://", "", domain_stok_baru).strip().rstrip('/')
    domain_clean = re.sub(r"^www\.", "", domain_clean)
    
    parsed = urlparse(full_url_lama)
    new_url = urlunparse(('https', domain_clean, parsed.path, parsed.params, parsed.query, parsed.fragment))
    return new_url

def do_migrate_stok():
    """Migrate old stok.txt to stok_data.json (run once)"""
    if os.path.exists(STOK_FILE):
        count = migrate_stok_txt_to_json(STOK_FILE, STOK_DATA_FILE)
        if count > 0:
            print(f"[MIGRATE] Migrated {count} domains from stok.txt to stok_data.json")
            # Rename old file so we don't migrate again
            try:
                os.rename(STOK_FILE, STOK_FILE + ".bak")
                print(f"[MIGRATE] stok.txt renamed to stok.txt.bak")
            except:
                pass

# =========================
# 3. FUNGSI API (KOMUNIKASI KE HOSTING)
# =========================

def buat_shortlink_hosting(url_tujuan, custom_alias=None):
    """Create new shortlink"""
    payload = {"key": API_SHORTLINK_KEY, "url": url_tujuan}
    if custom_alias: 
        payload["custom"] = custom_alias
    try:
        resp = requests.post(API_SHORTLINK_URL, json=payload, timeout=15)
        print(f"[API Create] Status: {resp.status_code}, Response: {resp.text[:200]}")
        data = resp.json()
        if data.get('status') == 'success': 
            return data.get('short_link') or data.get('shortlink')
        print(f"[API Create] Failed: {data.get('pesan', 'Unknown error')}")
        return None
    except Exception as e:
        print(f"[API Create] Error: {e}")
        return None

def update_shortlink_hosting(kode_unik, url_baru):
    """Update existing shortlink target URL"""
    payload = {
        "key": API_SHORTLINK_KEY,
        "action": "update",
        "kode": kode_unik,
        "url": url_baru
    }
    try:
        resp = requests.post(API_SHORTLINK_URL, json=payload, timeout=15)
        print(f"[API Update] Status: {resp.status_code}, Response: {resp.text[:200]}")
        data = resp.json()
        if data.get('status') == 'success':
            return True
        print(f"[API Update] Failed: {data.get('pesan', 'Unknown error')}")
        return False
    except Exception as e:
        print(f"[API Update] Error: {e}")
        return False

def delete_shortlink_hosting(kode_unik):
    """Delete shortlink from hosting"""
    payload = {
        "key": API_SHORTLINK_KEY,
        "action": "delete",
        "kode": kode_unik
    }
    try:
        resp = requests.post(API_SHORTLINK_URL, json=payload, timeout=15)
        print(f"[API Delete] Status: {resp.status_code}, Response: {resp.text[:200]}")
        data = resp.json()
        return data.get('status') == 'success'
    except Exception as e:
        print(f"[API Delete] Error: {e}")
        return False

def test_api_connection():
    """Test API connection"""
    payload = {
        "key": API_SHORTLINK_KEY,
        "action": "list"
    }
    try:
        resp = requests.post(API_SHORTLINK_URL, json=payload, timeout=10)
        data = resp.json()
        return data.get('status') == 'success', data
    except Exception as e:
        return False, str(e)

# =========================
# 4. AUTO GANTI (WITH STOK GROUP)
# =========================

def handle_domain_terblokir(domain_yang_blok: str) -> list:
    """
    Handle blocked domain - find affected shortlinks and replace them.
    Now uses stok group from each link's config.
    
    Flow:
    1. Find all shortlinks using this domain
    2. For each shortlink:
       - Get stok group from link info
       - Take new domain from that stok group
       - Build new URL (keep path & params)
       - Update via API
       - Update local database
       - Add new domain to monitoring
    
    Returns: List of notification messages
    """
    messages = []
    domain_clean = norm_domain(domain_yang_blok)
    
    print(f"\n[AUTO-GANTI] Processing blocked domain: {domain_clean}")
    
    # Find affected shortlinks
    affected_links = get_links_by_domain(domain_clean)
    
    if not affected_links:
        print(f"[AUTO-GANTI] No shortlinks found using domain: {domain_clean}")
        return []
    
    print(f"[AUTO-GANTI] Found {len(affected_links)} affected shortlinks")
    
    # Process each affected shortlink
    for nama_link, link_info in affected_links:
        url_lama = link_info['url']
        short_url = link_info['short']
        stok_group = link_info.get('stok', 'default')  # Get stok group for this link
        
        print(f"[AUTO-GANTI] Processing: {nama_link} (stok group: {stok_group})")
        print(f"  Old URL: {url_lama}")
        
        # Check stock availability for this group
        stok_tersedia = stok_peek(STOK_DATA_FILE, stok_group)
        stok_default = stok_peek(STOK_DATA_FILE, "default") if stok_group != "default" else 0
        
        if stok_tersedia == 0 and stok_default == 0:
            messages.append(
                f"⚠️ <b>STOK HABIS!</b>\n"
                f"Link <b>{nama_link}</b> tidak bisa diganti.\n"
                f"Domain lama: {domain_clean} (TERBLOKIR)\n"
                f"Stok grup '<b>{stok_group}</b>': 0\n"
                f"<i>Tambah stok dengan /addstok {stok_group} domain.com</i>"
            )
            continue
        
        # Get new domain from stok group (auto-fallback to default)
        domain_baru = stok_ambil(STOK_DATA_FILE, stok_group)
        
        if not domain_baru:
            messages.append(
                f"❌ <b>STOK HABIS!</b>\n"
                f"Link <b>{nama_link}</b> tidak bisa diganti.\n"
                f"Domain lama: {domain_clean} (TERBLOKIR)\n"
                f"<i>Segera tambah stok!</i>"
            )
            continue
        
        print(f"  New domain from stok [{stok_group}]: {domain_baru}")
        
        # Build new URL
        url_baru = ganti_domain_keep_path(url_lama, domain_baru)
        print(f"  New URL: {url_baru}")
        
        # Get shortlink code
        kode_unik = get_kode_from_shortlink(short_url)
        
        # Update via API
        sukses = update_shortlink_hosting(kode_unik, url_baru)
        
        if sukses:
            # Update local database (keep same stok group)
            update_link_local(nama_link, url_baru, short_url, stok_group)
            
            # Add new domain to monitoring
            domain_baru_clean = norm_domain(domain_baru)
            add_domain(DOMAINS_FILE, domain_baru_clean, "default", f"Pengganti {domain_clean}")
            
            # Stok info
            sisa_grup = stok_peek(STOK_DATA_FILE, stok_group)
            sisa_total = stok_peek(STOK_DATA_FILE)
            
            pesan = (
                f"🔄 <b>AUTO-GANTI BERHASIL!</b>\n\n"
                f"📛 Link: <b>{nama_link.upper()}</b>\n"
                f"❌ Domain Lama: <code>{domain_clean}</code> (BLOKIR)\n"
                f"✅ Domain Baru: <code>{domain_baru_clean}</code>\n\n"
                f"🔗 Shortlink: <code>{short_url}</code>\n"
                f"🎯 Target Baru: {url_baru}\n\n"
                f"📦 Stok [{stok_group}]: {sisa_grup} | Total: {sisa_total}"
            )
            messages.append(pesan)
            print(f"[AUTO-GANTI] SUCCESS: {nama_link} updated")
            
        else:
            # Return domain to stok since update failed
            stok_return_domain(STOK_DATA_FILE, stok_group, domain_baru)
            
            messages.append(
                f"❌ <b>GAGAL UPDATE!</b>\n"
                f"Link: {nama_link}\n"
                f"Error: Tidak bisa update di hosting.\n"
                f"<i>Cek koneksi API atau log server.</i>"
            )
            print(f"[AUTO-GANTI] FAILED: {nama_link} - API update failed")
    
    return messages

# =========================
# 5. COMMAND HANDLERS
# =========================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    add_grup(update.effective_chat.id)
    
    # Get stats
    domains_count = len(get_all_domains(DOMAINS_FILE))
    links_count = len(load_links())
    stok_total = stok_peek(STOK_DATA_FILE)
    stok_groups = stok_list_groups(STOK_DATA_FILE)
    groups = get_groups_sorted(DOMAINS_FILE)
    
    text = (
        "🤖 <b>Bot Nawala Checker V6</b>\n"
        "<i>Auto-monitoring & Auto-replace dengan Stok Group</i>\n\n"
        
        f"📊 <b>STATUS:</b>\n"
        f"  • Domain dipantau: {domains_count}\n"
        f"  • Shortlink aktif: {links_count}\n"
        f"  • Stok cadangan: {stok_total} ({len(stok_groups)} grup)\n"
        f"  • Grup domain: {len(groups)}\n\n"
        
        "<b>📋 SHORTLINK:</b>\n"
        "<code>/create [url] [nama] [stok_grup]</code>\n"
        "<code>/setactive [nama] [url] [stok_grup]</code>\n"
        "<code>/setstok [nama] [stok_grup]</code> - Ganti stok grup\n"
        "<code>/listactive</code> - Lihat shortlink\n"
        "<code>/delactive [nama]</code> - Hapus shortlink\n\n"
        
        "<b>🌐 DOMAIN:</b>\n"
        "<code>/adddomain [domain] [grup] [note]</code>\n"
        "<code>/deldomain [domain]</code>\n"
        "<code>/listdomain</code> atau <code>/listdomain [grup]</code>\n\n"
        
        "<b>📁 GRUP DOMAIN:</b>\n"
        "<code>/addgroup [nama] [prioritas]</code>\n"
        "<code>/listgroup</code>\n"
        "<code>/setpriority [grup] [angka]</code>\n\n"
        
        "<b>📦 STOK DOMAIN:</b>\n"
        "<code>/addstok [grup] [domain...]</code> - Tambah stok ke grup\n"
        "<code>/liststok</code> - Semua grup stok\n"
        "<code>/liststok [grup]</code> - Stok grup tertentu\n"
        "<code>/delstok [domain]</code> atau <code>/delstok [grup] [domain]</code>\n"
        "<code>/addstokgroup [nama] [deskripsi]</code>\n"
        "<code>/liststokgroup</code>\n"
        "<code>/delstokgroup [nama]</code>\n\n"
        
        "<b>🔍 CEK:</b>\n"
        "<code>/cek [domain]</code> - Cek manual\n"
        "<code>/cekgrup [nama]</code> - Cek per grup\n\n"
        
        "<b>🔧 TOOLS:</b>\n"
        "<code>/testapi</code> - Test koneksi API\n"
        "<code>/status</code> - Lihat status bot"
    )
    await update.message.reply_text(text, parse_mode="HTML")

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show bot status and statistics"""
    domains_data = load_domains_data(DOMAINS_FILE)
    links = load_links()
    groups = get_groups_sorted(DOMAINS_FILE)
    
    # Stok per group
    stok_info = stok_peek_all(STOK_DATA_FILE)
    stok_total = sum(stok_info.values())
    stok_lines = []
    for g, count in sorted(stok_info.items(), key=lambda x: -x[1]):
        stok_lines.append(f"  • {g}: {count} domain")
    
    # Count domains per group
    group_stats = []
    for g in groups:
        count = len(get_domains_by_group(DOMAINS_FILE, g))
        priority = domains_data.get("groups", {}).get(g, {}).get("priority", 99)
        group_stats.append(f"  • {g}: {count} domain (prioritas {priority})")
    
    # Shortlink stok mapping
    link_stok_lines = []
    for name, info in links.items():
        stok_g = info.get("stok", "default")
        domain = get_domain_from_url(info['url'])
        link_stok_lines.append(f"  • <b>{name}</b> → stok: {stok_g} ({domain})")
    
    # Test API
    api_ok, api_result = test_api_connection()
    api_status = "✅ Connected" if api_ok else "❌ Error"
    
    text = (
        "📊 <b>BOT STATUS V6</b>\n\n"
        
        f"<b>🔗 Shortlink:</b> {len(links)} aktif\n"
        f"<b>🌐 Domain:</b> {len(domains_data.get('domains', {}))} dipantau\n"
        f"<b>📦 Stok Total:</b> {stok_total} domain\n"
        f"<b>📡 API:</b> {api_status}\n\n"
        
        f"<b>📁 Grup Domain:</b>\n" + "\n".join(group_stats) + "\n\n"
        
        f"<b>📦 Stok per Grup:</b>\n" + "\n".join(stok_lines) + "\n\n"
    )
    
    if link_stok_lines:
        text += f"<b>🔗 Link → Stok Mapping:</b>\n" + "\n".join(link_stok_lines) + "\n\n"
    
    text += (
        f"<b>⏰ Auto-check:</b> Setiap 5 menit\n"
        f"<b>🔄 Auto-ganti:</b> Aktif (pakai stok grup)"
    )
    await update.message.reply_text(text, parse_mode="HTML")

async def testapi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Test API connection"""
    msg = await update.message.reply_text("⏳ Testing API connection...")
    
    ok, result = test_api_connection()
    
    if ok:
        total = result.get('total', 0)
        await msg.edit_text(
            f"✅ <b>API Connected!</b>\n\n"
            f"URL: {API_SHORTLINK_URL}\n"
            f"Total links di hosting: {total}",
            parse_mode="HTML"
        )
    else:
        await msg.edit_text(
            f"❌ <b>API Connection Failed!</b>\n\n"
            f"URL: {API_SHORTLINK_URL}\n"
            f"Error: {result}",
            parse_mode="HTML"
        )

async def cek(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Gunakan: /cek domain.com")
        return

    msg = await update.message.reply_text("⏳ Menghubungi TrustPositif...")
    domain = norm_domain(context.args[0])

    try:
        hasil = await asyncio.to_thread(bulk_cek_nawala, [domain])
        await msg.edit_text("\n".join(hasil))
    except Exception as e:
        await msg.edit_text(f"❌ Error Checker: {e}")

async def cekgrup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check all domains in a specific group"""
    if not context.args:
        groups = get_groups_sorted(DOMAINS_FILE)
        group_list = "\n".join([f"  • {g}" for g in groups])
        await update.message.reply_text(
            f"❌ Gunakan: <code>/cekgrup [nama_grup]</code>\n\n"
            f"<b>Grup tersedia:</b>\n{group_list}",
            parse_mode="HTML"
        )
        return

    grup_name = context.args[0].strip().lower()
    domains = get_domains_by_group(DOMAINS_FILE, grup_name)
    
    if not domains:
        await update.message.reply_text(f"❌ Grup '{grup_name}' kosong atau tidak ada.")
        return

    msg = await update.message.reply_text(
        f"⏳ Mengecek grup <b>{grup_name.upper()}</b>...\n"
        f"Total: {len(domains)} domain",
        parse_mode="HTML"
    )

    try:
        domains_info = []
        for d in domains:
            info = get_domain_info(DOMAINS_FILE, d)
            domains_info.append({
                "domain": d,
                "group": grup_name,
                "note": info.get("note", "") if info else ""
            })
        
        results = await asyncio.to_thread(bulk_cek_nawala_with_info, domains_info)
        
        lines = [f"📊 <b>HASIL CEK GRUP: {grup_name.upper()}</b>\n"]
        
        blokir_count = 0
        aman_count = 0
        
        for r in results:
            if r["status"] == "TERBLOKIR":
                status_icon = "🚫"
                blokir_count += 1
            elif r["status"] == "AMAN":
                status_icon = "✅"
                aman_count += 1
            else:
                status_icon = "❓"
            
            note_text = f" <i>({r['note']})</i>" if r.get('note') else ""
            lines.append(f"{status_icon} {r['domain']}{note_text}")
        
        lines.append(f"\n<b>Summary:</b> ✅ {aman_count} aman, 🚫 {blokir_count} blokir")
        
        await msg.edit_text("\n".join(lines), parse_mode="HTML")
        
        # Handle blocked domains
        if blokir_count > 0:
            for r in results:
                if r["status"] == "TERBLOKIR":
                    notifs = handle_domain_terblokir(r["domain"])
                    for notif in notifs:
                        await update.message.reply_text(notif, parse_mode="HTML")
        
    except Exception as e:
        await msg.edit_text(f"❌ Error: {e}")

# =========================
# SHORTLINK MANAGEMENT (UPDATED WITH STOK GROUP)
# =========================

async def create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Create shortlink with optional stok group
    Auto-detects URL vs nama, order doesn't matter!
    
    Usage: /create [nama] [url] [stok_grup]
    Or:    /create [url] [nama] [stok_grup]
    """
    add_grup(update.effective_chat.id)
    if len(context.args) < 2:
        stok_groups = stok_list_groups(STOK_DATA_FILE)
        group_list = ", ".join(stok_groups.keys())
        
        await update.message.reply_text(
            "❌ Gunakan: <code>/create [nama] [url] [stok_grup]</code>\n\n"
            "Contoh:\n"
            "<code>/create jumgacor https://jumtoto.com/register?ref=seo jum</code>\n"
            "<code>/create https://other.com/register linkother</code>\n\n"
            f"<b>Stok grup tersedia:</b> {group_list}\n"
            "<i>Tanpa stok_grup = pakai 'default'</i>",
            parse_mode="HTML"
        )
        return

    url_tujuan, nama_custom, stok_group = parse_create_args(context.args)
    
    if not url_tujuan or not nama_custom:
        await update.message.reply_text("❌ Tidak bisa mendeteksi URL dan nama. Coba lagi.")
        return

    msg = await update.message.reply_text(
        f"⏳ Membuat shortlink <b>{nama_custom}</b>...\n"
        f"📦 Stok grup: {stok_group}",
        parse_mode="HTML"
    )

    # Auto-create stok group if not exists
    stok_add_group(STOK_DATA_FILE, stok_group)

    # Try to create
    short_link = buat_shortlink_hosting(url_tujuan, custom_alias=nama_custom)

    if not short_link:
        sukses = update_shortlink_hosting(nama_custom, url_tujuan)
        if sukses:
            domain_hosting = API_SHORTLINK_URL.replace("/api.php", "")
            short_link = f"{domain_hosting}/{nama_custom}"
        else:
            await msg.edit_text(
                "❌ <b>Gagal membuat shortlink!</b>\n\n"
                "Kemungkinan:\n"
                "• Nama sudah dipakai\n"
                "• Server hosting down\n"
                "• API key salah\n\n"
                "Coba <code>/testapi</code> untuk cek koneksi.",
                parse_mode="HTML"
            )
            return

    # Save locally WITH stok group
    update_link_local(nama_custom, url_tujuan, short_link, stok_group)
    
    # Add domain to monitoring
    domain_only = norm_domain(url_tujuan)
    add_domain(DOMAINS_FILE, domain_only, "default", f"Shortlink: {nama_custom}")

    stok_count = stok_peek(STOK_DATA_FILE, stok_group)

    await msg.edit_text(
        f"✅ <b>Shortlink Berhasil!</b>\n\n"
        f"📛 Nama: <b>{nama_custom}</b>\n"
        f"🔗 Short: <code>{short_link}</code>\n"
        f"🎯 Target: {url_tujuan}\n"
        f"📦 Stok grup: <b>{stok_group}</b> ({stok_count} domain)\n\n"
        f"<i>Domain {domain_only} ditambahkan ke monitoring.</i>\n"
        f"<i>Auto-ganti akan ambil stok dari grup '{stok_group}'</i>",
        parse_mode="HTML"
    )

async def setactive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Update shortlink target, optionally change stok group
    Auto-detects URL vs nama
    Usage: /setactive [nama] [url] [stok_grup]
    """
    add_grup(update.effective_chat.id)
    if len(context.args) < 2:
        await update.message.reply_text(
            "❌ Gunakan: <code>/setactive [nama] [url] [stok_grup]</code>\n\n"
            "Contoh:\n"
            "<code>/setactive jumgacor https://newdomain.com/register</code>\n"
            "<code>/setactive jumgacor https://newdomain.com/register jum</code>",
            parse_mode="HTML"
        )
        return

    url_tujuan, nama_custom, stok_group_arg = parse_create_args(context.args)
    
    if not url_tujuan or not nama_custom:
        await update.message.reply_text("❌ Tidak bisa mendeteksi URL dan nama. Coba lagi.")
        return
    
    # Get existing stok group or use provided one
    existing = load_links().get(nama_custom, {})
    stok_group = stok_group_arg if len(context.args) > 2 else existing.get("stok", "default")

    msg = await update.message.reply_text(f"⏳ Updating <b>{nama_custom}</b>...", parse_mode="HTML")

    short_link = buat_shortlink_hosting(url_tujuan, custom_alias=nama_custom)
    
    if not short_link:
        sukses = update_shortlink_hosting(nama_custom, url_tujuan)
        if sukses:
            domain_hosting = API_SHORTLINK_URL.replace("/api.php", "")
            short_link = f"{domain_hosting}/{nama_custom}"
        else:
            await msg.edit_text("❌ Gagal update shortlink.", parse_mode="HTML")
            return

    update_link_local(nama_custom, url_tujuan, short_link, stok_group)
    domain_only = norm_domain(url_tujuan)
    add_domain(DOMAINS_FILE, domain_only, "default", f"Shortlink: {nama_custom}")

    await msg.edit_text(
        f"✅ <b>Shortlink Updated!</b>\n\n"
        f"📛 Nama: <b>{nama_custom}</b>\n"
        f"🔗 Short: <code>{short_link}</code>\n"
        f"🎯 Target: {url_tujuan}\n"
        f"📦 Stok grup: <b>{stok_group}</b>",
        parse_mode="HTML"
    )

async def setstok(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Change stok group for existing shortlink
    Usage: /setstok [nama_link] [stok_grup]
    """
    if len(context.args) < 2:
        links = load_links()
        if links:
            lines = ["❌ Gunakan: <code>/setstok [nama] [stok_grup]</code>\n\n<b>Shortlink aktif:</b>"]
            for name, info in links.items():
                lines.append(f"  • {name} → stok: {info.get('stok', 'default')}")
            await update.message.reply_text("\n".join(lines), parse_mode="HTML")
        else:
            await update.message.reply_text("❌ Gunakan: <code>/setstok [nama] [stok_grup]</code>", parse_mode="HTML")
        return
    
    nama = context.args[0].strip()
    stok_group = context.args[1].strip().lower()
    
    data = load_links()
    if nama not in data:
        await update.message.reply_text(f"❌ Shortlink '{nama}' tidak ditemukan.")
        return
    
    # Auto-create stok group
    stok_add_group(STOK_DATA_FILE, stok_group)
    
    # Update stok group
    data[nama]["stok"] = stok_group
    save_links(data)
    
    stok_count = stok_peek(STOK_DATA_FILE, stok_group)
    
    await update.message.reply_text(
        f"✅ <b>Stok grup diupdate!</b>\n\n"
        f"📛 Link: <b>{nama}</b>\n"
        f"📦 Stok grup: <b>{stok_group}</b> ({stok_count} domain)\n\n"
        f"<i>Auto-ganti akan ambil stok dari grup '{stok_group}'</i>",
        parse_mode="HTML"
    )

async def listactive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = load_links()
    if not data:
        await update.message.reply_text("📭 Belum ada shortlink aktif.")
        return
    
    lines = [f"📋 <b>SHORTLINK AKTIF ({len(data)})</b>\n"]
    
    for nama, info in data.items():
        domain = get_domain_from_url(info['url'])
        stok_group = info.get('stok', 'default')
        stok_count = stok_peek(STOK_DATA_FILE, stok_group)
        lines.append(
            f"\n🔹 <b>{nama.upper()}</b>\n"
            f"   Short: <code>{info['short']}</code>\n"
            f"   Domain: {domain}\n"
            f"   📦 Stok: <b>{stok_group}</b> ({stok_count} tersedia)"
        )
    
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

async def delactive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete shortlink - both local and hosting"""
    if not context.args:
        await update.message.reply_text("❌ Gunakan: <code>/delactive [nama]</code>", parse_mode="HTML")
        return
    
    nama = context.args[0].strip()
    data = load_links()
    
    if nama not in data:
        await update.message.reply_text(f"❌ Shortlink '{nama}' tidak ditemukan.")
        return
    
    msg = await update.message.reply_text(f"⏳ Menghapus {nama}...")
    
    hosting_deleted = delete_shortlink_hosting(nama)
    domain_in_link = get_domain_from_url(data[nama]['url'])
    local_deleted = delete_link_local(nama)
    remove_domain(DOMAINS_FILE, domain_in_link)
    
    if hosting_deleted and local_deleted:
        await msg.edit_text(
            f"✅ <b>Shortlink '{nama}' dihapus!</b>\n\n"
            f"• Dihapus dari hosting ✓\n"
            f"• Dihapus dari lokal ✓\n"
            f"• Domain {domain_in_link} dihapus dari monitoring",
            parse_mode="HTML"
        )
    elif local_deleted:
        await msg.edit_text(
            f"⚠️ <b>Shortlink '{nama}' dihapus sebagian</b>\n\n"
            f"• Dihapus dari lokal ✓\n"
            f"• Gagal hapus dari hosting ✗\n\n"
            f"<i>Mungkin sudah tidak ada di hosting.</i>",
            parse_mode="HTML"
        )
    else:
        await msg.edit_text(f"❌ Gagal menghapus '{nama}'.")

# =========================
# DOMAIN MANAGEMENT
# =========================

async def adddomain(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add domain with optional group and note"""
    if not context.args:
        groups = get_groups_sorted(DOMAINS_FILE)
        group_list = ", ".join(groups)
        
        await update.message.reply_text(
            "❌ <b>Cara pakai:</b>\n\n"
            "<code>/adddomain [domain] [grup] [catatan]</code>\n\n"
            "<b>Contoh:</b>\n"
            "<code>/adddomain jumtoto.com</code>\n"
            "<code>/adddomain jumtoto.com jumdomain</code>\n"
            "<code>/adddomain jumtoto.com jumdomain link utama JUM</code>\n\n"
            f"<b>Grup tersedia:</b> {group_list}\n\n"
            "<i>Buat grup baru dengan /addgroup</i>",
            parse_mode="HTML"
        )
        return
    
    domain = norm_domain(context.args[0])
    grup = context.args[1].lower() if len(context.args) > 1 else "default"
    note = " ".join(context.args[2:]) if len(context.args) > 2 else ""
    
    data = load_domains_data(DOMAINS_FILE)
    if grup not in data.get("groups", {}):
        add_group(DOMAINS_FILE, grup)
    
    add_domain(DOMAINS_FILE, domain, grup, note)
    
    note_text = f"\n📝 Catatan: {note}" if note else ""
    group_priority = data.get("groups", {}).get(grup, {}).get("priority", 99)
    
    await update.message.reply_text(
        f"✅ <b>Domain ditambahkan!</b>\n\n"
        f"🌐 Domain: <code>{domain}</code>\n"
        f"📁 Grup: {grup} (prioritas {group_priority}){note_text}",
        parse_mode="HTML"
    )

async def deldomain(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete domain from monitoring"""
    if not context.args:
        await update.message.reply_text("❌ Gunakan: <code>/deldomain domain.com</code>", parse_mode="HTML")
        return
    
    domain = norm_domain(context.args[0])
    affected = get_links_by_domain(domain)
    
    if remove_domain(DOMAINS_FILE, domain):
        warning = ""
        if affected:
            names = [a[0] for a in affected]
            warning = f"\n\n⚠️ <b>Perhatian:</b> Domain ini dipakai oleh shortlink: {', '.join(names)}"
        
        await update.message.reply_text(
            f"🗑️ Domain <code>{domain}</code> dihapus dari monitoring.{warning}",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(f"❌ Domain '{domain}' tidak ditemukan.")

async def listdomain(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List domains, optionally filtered by group"""
    filter_grup = context.args[0].lower() if context.args else None
    
    data = load_domains_data(DOMAINS_FILE)
    domains = data.get("domains", {})
    groups = data.get("groups", {})
    
    if not domains:
        await update.message.reply_text("📭 Tidak ada domain yang dipantau.")
        return
    
    grouped = {}
    for domain, info in domains.items():
        g = info.get("group", "default")
        if filter_grup and g != filter_grup:
            continue
        if g not in grouped:
            grouped[g] = []
        grouped[g].append({"domain": domain, "note": info.get("note", "")})
    
    if not grouped:
        await update.message.reply_text(f"📭 Grup '{filter_grup}' kosong atau tidak ada.")
        return
    
    sorted_groups = sorted(grouped.keys(), key=lambda g: groups.get(g, {}).get("priority", 99))
    
    lines = ["📋 <b>DOMAIN MONITORING</b>\n"]
    
    for g in sorted_groups:
        priority = groups.get(g, {}).get("priority", 99)
        lines.append(f"\n📁 <b>{g.upper()}</b> (prioritas: {priority})")
        
        for d in sorted(grouped[g], key=lambda x: x['domain']):
            note_text = f" - <i>{d['note']}</i>" if d['note'] else ""
            lines.append(f"  🔹 {d['domain']}{note_text}")
    
    total = sum(len(v) for v in grouped.values())
    lines.append(f"\n<b>Total:</b> {total} domain")
    
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

# =========================
# GROUP MANAGEMENT
# =========================

async def addgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add new domain group with priority"""
    if not context.args:
        await update.message.reply_text(
            "❌ <b>Cara pakai:</b>\n\n"
            "<code>/addgroup [nama] [prioritas]</code>\n\n"
            "<b>Contoh:</b>\n"
            "<code>/addgroup jumdomain 1</code>\n"
            "<code>/addgroup backup 5</code>\n\n"
            "<b>Prioritas:</b>\n"
            "• Angka lebih kecil = dicek duluan\n"
            "• Default = 99 (dicek terakhir)",
            parse_mode="HTML"
        )
        return
    
    grup_name = context.args[0].lower()
    priority = int(context.args[1]) if len(context.args) > 1 else None
    
    add_group(DOMAINS_FILE, grup_name, priority)
    
    data = load_domains_data(DOMAINS_FILE)
    final_priority = data["groups"][grup_name]["priority"]
    
    await update.message.reply_text(
        f"✅ <b>Grup '{grup_name}' dibuat!</b>\n\n"
        f"Prioritas: {final_priority}\n\n"
        f"<i>Tambah domain dengan:</i>\n"
        f"<code>/adddomain domain.com {grup_name} catatan</code>",
        parse_mode="HTML"
    )

async def delgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete group (domains moved to default)"""
    if not context.args:
        await update.message.reply_text("❌ Gunakan: <code>/delgroup [nama]</code>", parse_mode="HTML")
        return
    
    grup_name = context.args[0].lower()
    
    if grup_name == "default":
        await update.message.reply_text("❌ Grup 'default' tidak bisa dihapus.")
        return
    
    domains_in_group = get_domains_by_group(DOMAINS_FILE, grup_name)
    
    if remove_group(DOMAINS_FILE, grup_name):
        await update.message.reply_text(
            f"🗑️ <b>Grup '{grup_name}' dihapus!</b>\n\n"
            f"{len(domains_in_group)} domain dipindahkan ke grup 'default'.",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(f"❌ Grup '{grup_name}' tidak ditemukan.")

async def listgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all groups with their priority and domain count"""
    data = load_domains_data(DOMAINS_FILE)
    groups = data.get("groups", {})
    
    if not groups:
        await update.message.reply_text("📭 Tidak ada grup.")
        return
    
    sorted_groups = sorted(groups.items(), key=lambda x: x[1].get("priority", 99))
    
    lines = ["📁 <b>GRUP DOMAIN</b>\n"]
    lines.append("<i>Prioritas kecil = dicek duluan</i>\n")
    
    for name, info in sorted_groups:
        domain_count = len(get_domains_by_group(DOMAINS_FILE, name))
        priority = info.get("priority", 99)
        
        if priority <= 3:
            emoji = "🥇" if priority == 1 else "🥈" if priority == 2 else "🥉"
        else:
            emoji = "📁"
        
        lines.append(f"{emoji} <b>{name}</b> - Prioritas: {priority} ({domain_count} domain)")
    
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

async def setpriority(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set group priority"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "❌ Gunakan: <code>/setpriority [grup] [angka]</code>\n\n"
            "Contoh: <code>/setpriority jumdomain 1</code>",
            parse_mode="HTML"
        )
        return
    
    grup_name = context.args[0].lower()
    try:
        priority = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Prioritas harus angka.")
        return
    
    if set_group_priority(DOMAINS_FILE, grup_name, priority):
        await update.message.reply_text(
            f"✅ Prioritas grup '<b>{grup_name}</b>' diset ke <b>{priority}</b>",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(f"❌ Grup '{grup_name}' tidak ditemukan.")

# =========================
# STOK MANAGEMENT (NEW - GROUP BASED)
# =========================

async def addstok(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Add domains to stok group
    Usage: /addstok [grup] domain1 domain2 ...
    If first arg is not a domain, treat as group name
    
    Examples:
    /addstok jum domain1.com domain2.com     → add to group 'jum'
    /addstok domain1.com domain2.com          → add to 'default'
    """
    teks = update.message.text.replace("/addstok", "").strip()
    
    if not teks:
        stok_groups = stok_list_groups(STOK_DATA_FILE)
        group_list = ", ".join(stok_groups.keys())
        
        await update.message.reply_text(
            "❌ <b>Cara pakai:</b>\n\n"
            "<code>/addstok [grup] domain1.com domain2.com</code>\n\n"
            "<b>Contoh:</b>\n"
            "<code>/addstok jum domain1.com domain2.com</code>\n"
            "<code>/addstok domain1.com domain2.com</code> (masuk default)\n\n"
            f"<b>Stok grup tersedia:</b> {group_list}\n"
            "<i>Grup baru otomatis dibuat jika belum ada</i>",
            parse_mode="HTML"
        )
        return
    
    parts = teks.split()
    
    # Detect if first word is a group name (not a domain)
    first_word = parts[0].lower()
    is_domain = bool(re.match(r'^[a-z0-9\-\.]+\.[a-z]{2,}$', first_word))
    
    if is_domain:
        # All args are domains, use default group
        group_name = "default"
        domain_text = teks
    else:
        # First arg is group name
        group_name = first_word
        domain_text = " ".join(parts[1:])
    
    domains = list(set(re.findall(r'\b[a-z0-9\-\.]+\.[a-z]{2,}\b', domain_text.lower())))
    
    if not domains:
        await update.message.reply_text(
            f"❌ Tidak ada domain valid ditemukan.\n\n"
            f"Contoh: <code>/addstok {group_name} domain1.com domain2.com</code>",
            parse_mode="HTML"
        )
        return
    
    added, skipped = stok_add_domains(STOK_DATA_FILE, group_name, domains)
    
    total_grup = stok_peek(STOK_DATA_FILE, group_name)
    total_all = stok_peek(STOK_DATA_FILE)
    skip_text = f"\n⚠️ {skipped} domain sudah ada di stok." if skipped > 0 else ""
    
    await update.message.reply_text(
        f"✅ <b>{added} domain masuk stok [{group_name}]!</b>{skip_text}\n\n"
        f"📦 Stok [{group_name}]: {total_grup} domain\n"
        f"📦 Total semua stok: {total_all} domain",
        parse_mode="HTML"
    )

async def liststok(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Show stock - all groups or specific group
    Usage: /liststok [grup]
    """
    filter_group = context.args[0].lower() if context.args else None
    
    data = load_stok_data(STOK_DATA_FILE)
    groups = data.get("groups", {})
    
    total_all = sum(len(g.get("domains", [])) for g in groups.values())
    
    if total_all == 0 and not filter_group:
        await update.message.reply_text(
            "📭 <b>Stok kosong!</b>\n\n"
            "<i>Tambah stok dengan /addstok [grup] domain.com</i>",
            parse_mode="HTML"
        )
        return
    
    if filter_group:
        # Show specific group
        if filter_group not in groups:
            await update.message.reply_text(f"❌ Stok grup '{filter_group}' tidak ditemukan.")
            return
        
        domains = groups[filter_group].get("domains", [])
        desc = groups[filter_group].get("description", "")
        
        if not domains:
            await update.message.reply_text(
                f"📭 Stok grup '<b>{filter_group}</b>' kosong.\n\n"
                f"<i>Tambah dengan: /addstok {filter_group} domain.com</i>",
                parse_mode="HTML"
            )
            return
        
        lines = [f"📦 <b>STOK [{filter_group.upper()}]</b> ({len(domains)})\n"]
        if desc:
            lines.append(f"<i>{desc}</i>\n")
        
        display = domains[:50]
        for i, d in enumerate(display, 1):
            lines.append(f"{i}. {d}")
        
        if len(domains) > 50:
            lines.append(f"\n<i>...dan {len(domains) - 50} domain lagi</i>")
        
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")
    else:
        # Show all groups overview
        lines = [f"📦 <b>STOK DOMAIN (Total: {total_all})</b>\n"]
        
        for name, info in sorted(groups.items(), key=lambda x: -len(x[1].get("domains", []))):
            domains = info.get("domains", [])
            desc = info.get("description", "")
            count = len(domains)
            
            lines.append(f"\n📁 <b>{name.upper()}</b> ({count} domain)")
            if desc:
                lines.append(f"   <i>{desc}</i>")
            
            # Show first 5 domains
            preview = domains[:5]
            for d in preview:
                lines.append(f"   • {d}")
            if count > 5:
                lines.append(f"   <i>...+{count - 5} lagi</i>")
        
        lines.append(f"\n<i>Detail: /liststok [nama_grup]</i>")
        
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

async def delstok(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Delete domain from stok
    Usage: /delstok [domain]  → search all groups
    Usage: /delstok [grup] [domain]  → from specific group
    """
    if not context.args:
        await update.message.reply_text(
            "❌ <b>Cara pakai:</b>\n\n"
            "<code>/delstok domain.com</code> (cari di semua grup)\n"
            "<code>/delstok jum domain.com</code> (hapus dari grup 'jum')",
            parse_mode="HTML"
        )
        return
    
    if len(context.args) >= 2:
        # /delstok [grup] [domain]
        first = context.args[0].lower()
        second = context.args[1].lower()
        
        # Check if first arg is a group
        groups = stok_list_groups(STOK_DATA_FILE)
        if first in groups:
            group_name = first
            domain = second
        else:
            group_name = None
            domain = first
    else:
        group_name = None
        domain = context.args[0].strip().lower()
    
    if stok_remove_domain(STOK_DATA_FILE, domain, group_name):
        total = stok_peek(STOK_DATA_FILE)
        group_text = f" dari grup '{group_name}'" if group_name else ""
        await update.message.reply_text(
            f"🗑️ '<code>{domain}</code>' dihapus dari stok{group_text}.\n"
            f"📦 Total stok: {total}",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(f"❌ '{domain}' tidak ada di stok.")

async def addstokgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Create new stok group
    Usage: /addstokgroup [nama] [deskripsi...]
    """
    if not context.args:
        await update.message.reply_text(
            "❌ <b>Cara pakai:</b>\n\n"
            "<code>/addstokgroup [nama] [deskripsi]</code>\n\n"
            "<b>Contoh:</b>\n"
            "<code>/addstokgroup jum Stok domain untuk JUM</code>\n"
            "<code>/addstokgroup hoki Stok domain Hoki88</code>",
            parse_mode="HTML"
        )
        return
    
    group_name = context.args[0].lower()
    description = " ".join(context.args[1:]) if len(context.args) > 1 else ""
    
    stok_add_group(STOK_DATA_FILE, group_name, description)
    
    await update.message.reply_text(
        f"✅ <b>Stok grup '{group_name}' dibuat!</b>\n\n"
        f"📝 Deskripsi: {description or '-'}\n\n"
        f"<i>Tambah domain:</i>\n"
        f"<code>/addstok {group_name} domain1.com domain2.com</code>\n\n"
        f"<i>Arahkan shortlink ke grup ini:</i>\n"
        f"<code>/setstok [nama_link] {group_name}</code>",
        parse_mode="HTML"
    )

async def liststokgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all stok groups"""
    groups = stok_list_groups(STOK_DATA_FILE)
    
    if not groups:
        await update.message.reply_text("📭 Tidak ada stok grup.")
        return
    
    # Also get which links use which stok group
    links = load_links()
    links_per_group = {}
    for name, info in links.items():
        sg = info.get("stok", "default")
        if sg not in links_per_group:
            links_per_group[sg] = []
        links_per_group[sg].append(name)
    
    lines = ["📦 <b>STOK GRUP</b>\n"]
    
    total = 0
    for name, info in sorted(groups.items()):
        count = info["count"]
        desc = info["description"]
        total += count
        
        using_links = links_per_group.get(name, [])
        link_text = f"\n   🔗 Dipakai: {', '.join(using_links)}" if using_links else ""
        
        lines.append(
            f"📁 <b>{name}</b> - {count} domain\n"
            f"   📝 {desc}{link_text}"
        )
    
    lines.append(f"\n<b>Total stok:</b> {total} domain")
    
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

async def delstokgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete stok group (domains moved to default)"""
    if not context.args:
        await update.message.reply_text("❌ Gunakan: <code>/delstokgroup [nama]</code>", parse_mode="HTML")
        return
    
    group_name = context.args[0].lower()
    
    if group_name == "default":
        await update.message.reply_text("❌ Stok grup 'default' tidak bisa dihapus.")
        return
    
    # Check if any links use this stok group
    links = load_links()
    affected_links = [name for name, info in links.items() if info.get("stok") == group_name]
    
    remaining = stok_peek(STOK_DATA_FILE, group_name)
    
    if stok_remove_group(STOK_DATA_FILE, group_name):
        warning = ""
        if affected_links:
            # Move affected links to default stok
            for name in affected_links:
                links[name]["stok"] = "default"
            save_links(links)
            warning = f"\n\n⚠️ Shortlink dipindah ke stok 'default': {', '.join(affected_links)}"
        
        await update.message.reply_text(
            f"🗑️ <b>Stok grup '{group_name}' dihapus!</b>\n\n"
            f"📦 {remaining} domain dipindahkan ke stok 'default'.{warning}",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(f"❌ Stok grup '{group_name}' tidak ditemukan.")

# =========================
# 6. AUTO CHECK (IMPROVED - GROUP BY GROUP)
# =========================

async def run_autocheck(app):
    """
    Auto-check loop - runs every 5 minutes
    """
    print("🚀 Auto-Check Service: STARTED")
    print(f"   Check interval: 5 minutes")
    print(f"   Max domains per batch: 5")
    
    while True:
        jam = time.strftime("%H:%M")
        tanggal = time.strftime("%Y-%m-%d")
        
        try:
            # 1. Get groups in priority order
            groups_order = get_groups_sorted(DOMAINS_FILE)
            domains_data = load_domains_data(DOMAINS_FILE)
            active_data = load_links()
            
            if not domains_data.get("domains") and not active_data:
                print(f"[{jam}] 📭 Tidak ada domain untuk dicek.")
                await asyncio.sleep(300)
                continue
            
            print(f"\n{'='*50}")
            print(f"[{jam}] 🔍 MULAI AUTO-CHECK")
            print(f"{'='*50}")
            
            # 2. Prepare domains by group
            domains_by_group = {}
            
            for domain, info in domains_data.get("domains", {}).items():
                g = info.get("group", "default")
                if g not in domains_by_group:
                    domains_by_group[g] = []
                domains_by_group[g].append({
                    "domain": domain,
                    "group": g,
                    "note": info.get("note", "")
                })
            
            # Add domains from active shortlinks
            monitored = [d for group_domains in domains_by_group.values() for d in [x["domain"] for x in group_domains]]
            for link_name, info in active_data.items():
                d = get_domain_from_url(info['url'])
                if d and d not in monitored:
                    if "default" not in domains_by_group:
                        domains_by_group["default"] = []
                    domains_by_group["default"].append({
                        "domain": d,
                        "group": "default",
                        "note": f"Shortlink: {link_name}"
                    })
            
            # 3. Check each group in priority order
            all_results = {}
            total_blokir = 0
            total_aman = 0
            notif_list = []
            
            for group in groups_order:
                if group not in domains_by_group or not domains_by_group[group]:
                    continue
                
                group_domains = domains_by_group[group]
                priority = domains_data.get("groups", {}).get(group, {}).get("priority", 99)
                
                print(f"\n[{jam}] 📁 GRUP: {group.upper()} (prioritas {priority})")
                print(f"       Domains: {len(group_domains)}")
                
                try:
                    results = await asyncio.to_thread(bulk_cek_nawala_with_info, group_domains)
                    all_results[group] = results
                    
                    for r in results:
                        status = r.get("status", "UNKNOWN")
                        domain = r.get("domain", "")
                        note = r.get("note", "")
                        
                        if status == "TERBLOKIR":
                            total_blokir += 1
                            print(f"       🚫 BLOKIR: {domain} ({note})")
                            
                            msgs = handle_domain_terblokir(domain)
                            notif_list.extend(msgs)
                            
                        elif status == "AMAN":
                            total_aman += 1
                            print(f"       ✅ AMAN: {domain}")
                        else:
                            print(f"       ❓ {status}: {domain}")
                    
                except Exception as e:
                    print(f"[{jam}] ❌ Error checking group {group}: {e}")
                    all_results[group] = [{
                        "domain": d["domain"],
                        "status": "ERROR",
                        "note": d.get("note", "")
                    } for d in group_domains]
                
                await asyncio.sleep(2)
            
            # 4. Send blocked notifications first
            if notif_list:
                print(f"\n[{jam}] 🚨 SENDING {len(notif_list)} BLOCK NOTIFICATIONS...")
                for gid in read_list(GRUP_FILE):
                    try:
                        for notif in notif_list:
                            await app.bot.send_message(chat_id=int(gid), text=notif, parse_mode="HTML")
                            await asyncio.sleep(0.5)
                    except Exception as e:
                        print(f"[{jam}] ⚠️ Failed to send to {gid}: {e}")
            
            # 5. Build and send routine report
            print(f"\n[{jam}] 📊 Building routine report...")
            
            # Get stok info per group
            stok_info = stok_peek_all(STOK_DATA_FILE)
            stok_total = sum(stok_info.values())
            
            report_lines = [
                f"⏰ <b>AUTO-CHECK {jam} WIB</b>",
                f"📅 {tanggal}\n"
            ]
            
            for group in groups_order:
                if group not in all_results:
                    continue
                
                results = all_results[group]
                priority = domains_data.get("groups", {}).get(group, {}).get("priority", 99)
                
                report_lines.append(f"📁 <b>{group.upper()}</b> <i>(prioritas {priority})</i>")
                
                for r in results:
                    status = r.get("status", "UNKNOWN")
                    domain = r.get("domain", "")
                    note = r.get("note", "")
                    
                    if status == "TERBLOKIR":
                        icon = "🚫"
                    elif status == "AMAN":
                        icon = "✅"
                    elif status == "ERROR":
                        icon = "❌"
                    else:
                        icon = "❓"
                    
                    note_text = f" <i>({note})</i>" if note else ""
                    report_lines.append(f"  {icon} {domain}{note_text}")
                
                report_lines.append("")
            
            # Summary with stok per group
            report_lines.append(f"<b>📊 Summary:</b>")
            report_lines.append(f"  ✅ Aman: {total_aman}")
            report_lines.append(f"  🚫 Blokir: {total_blokir}")
            report_lines.append(f"  📦 Stok Total: {stok_total}")
            
            # Stok per group breakdown
            for sg, sc in sorted(stok_info.items()):
                report_lines.append(f"     📦 [{sg}]: {sc}")
            
            # Shortlinks section with stok group
            if active_data:
                report_lines.append(f"\n<b>🔗 Shortlink Aktif:</b>")
                for name, info in active_data.items():
                    domain = get_domain_from_url(info['url'])
                    stok_g = info.get('stok', 'default')
                    report_lines.append(f"  • <b>{name}</b>: {info['short']}")
                    report_lines.append(f"    → {domain} (stok: {stok_g})")
            
            report_message = "\n".join(report_lines)
            
            for gid in read_list(GRUP_FILE):
                try:
                    await app.bot.send_message(chat_id=int(gid), text=report_message, parse_mode="HTML")
                except Exception as e:
                    print(f"[{jam}] ⚠️ Failed to send report to {gid}: {e}")
            
            print(f"\n[{jam}] ✅ AUTO-CHECK COMPLETE")
            print(f"       Aman: {total_aman} | Blokir: {total_blokir}")
            print(f"{'='*50}")
            
        except Exception as e:
            print(f"[{jam}] ❌ Auto-check error: {e}")
            import traceback
            traceback.print_exc()
        
        print(f"\n[{jam}] 💤 Next check in 5 minutes...\n")
        await asyncio.sleep(300)

# =========================
# BOT STARTUP
# =========================

async def start_bot():
    # Migrate old stok.txt if exists
    do_migrate_stok()
    
    app = ApplicationBuilder().token(TOKEN).build()
    
    # Register all commands
    commands = [
        # Basic
        ("start", start),
        ("status", status),
        ("testapi", testapi),
        ("cek", cek),
        ("cekgrup", cekgrup),
        
        # Shortlink
        ("create", create),
        ("setactive", setactive),
        ("setstok", setstok),       # NEW
        ("listactive", listactive),
        ("delactive", delactive),
        
        # Domain monitoring
        ("adddomain", adddomain),
        ("deldomain", deldomain),
        ("listdomain", listdomain),
        
        # Domain Groups
        ("addgroup", addgroup),
        ("delgroup", delgroup),
        ("listgroup", listgroup),
        ("setpriority", setpriority),
        
        # Stok (grouped)
        ("addstok", addstok),
        ("liststok", liststok),
        ("delstok", delstok),
        ("addstokgroup", addstokgroup),   # NEW
        ("liststokgroup", liststokgroup),  # NEW
        ("delstokgroup", delstokgroup),    # NEW
    ]
    
    for cmd, handler in commands:
        app.add_handler(CommandHandler(cmd, handler))
    
    # Start auto-check task
    asyncio.create_task(run_autocheck(app))
    
    print("=" * 50)
    print("🤖 Bot Nawala Checker V6 AKTIF!")
    print("   Fitur: Stok Group System")
    print("=" * 50)
    print(f"📡 API: {API_SHORTLINK_URL}")
    print(f"⏰ Auto-check: Every 5 minutes")
    print("=" * 50)
    
    await app.run_polling()
