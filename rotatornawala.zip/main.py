import asyncio
import nest_asyncio
from bot import start_bot

nest_asyncio.apply()
loop = asyncio.get_event_loop()
loop.run_until_complete(start_bot())
