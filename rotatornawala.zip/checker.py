from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import time
import logging
import traceback

# Setup Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==========================================
# KONFIGURASI VPS
# ==========================================
CHROME_BINARY = "/usr/bin/chromium-browser"
CHROMEDRIVER_PATH = "/usr/bin/chromedriver"

# Limit TrustPositif hanya bisa cek 5 domain per request
MAX_DOMAINS_PER_CHECK = 5

def init_driver():
    """Initialize Chrome/Chromium driver"""
    options = Options()
    options.binary_location = CHROME_BINARY

    options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--remote-debugging-port=9222") 
    
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    options.add_argument(f"user-agent={user_agent}")

    try:
        service = Service(CHROMEDRIVER_PATH)
        driver = webdriver.Chrome(service=service, options=options)
        return driver
    except Exception as e:
        logger.error(f"Gagal init driver: {e}")
        raise e

def check_batch(driver, domains: list, wait) -> dict:
    """
    Check a batch of domains (max 5)
    Returns dict: {domain: {"status": "AMAN"|"TERBLOKIR", "raw": original_text}}
    """
    results = {}
    
    if not domains:
        return results
    
    try:
        url = "https://trustpositif.komdigi.go.id/"
        logger.info(f"Membuka {url} untuk batch {len(domains)} domain...")
        driver.get(url)

        # Refresh untuk aktivasi modal
        time.sleep(3)
        driver.refresh()
        time.sleep(5)

        # 1. Klik Modal
        try:
            trigger = wait.until(EC.element_to_be_clickable((By.ID, "press-to-modal")))
            try:
                trigger.click()
            except:
                driver.execute_script("arguments[0].click();", trigger)
            time.sleep(3)
        except Exception:
            logger.error("Gagal klik modal")
            for d in domains:
                results[d] = {"status": "ERROR", "raw": "Gagal klik modal"}
            return results

        # 2. Input Data
        try:
            textarea = wait.until(EC.visibility_of_element_located((By.ID, "input-data")))
            textarea.clear()
            valid_domains = [d for d in domains if d.strip()]
            textarea.send_keys("\n".join(valid_domains))
        except Exception:
            logger.error("Kolom input gagal diakses")
            for d in domains:
                results[d] = {"status": "ERROR", "raw": "Kolom input gagal"}
            return results

        # 3. Klik Cari
        try:
            tombol_cari = wait.until(EC.element_to_be_clickable((By.ID, "text-footer1")))
            tombol_cari.click()
        except:
            driver.execute_script("arguments[0].click();", driver.find_element(By.ID, "text-footer1"))

        time.sleep(5) 

        # 4. Parse Hasil
        soup = BeautifulSoup(driver.page_source, "html.parser")
        rows = soup.select("table#daftar-block tbody tr")
        
        if not rows:
            for d in domains:
                results[d] = {"status": "UNKNOWN", "raw": "Tidak ada hasil"}
            return results

        for row in rows:
            cols = row.find_all("td")
            if len(cols) >= 2:
                domain_text = cols[0].text.strip().lower()
                status_text = cols[1].text.strip().lower()

                # Logika: "tidak" = aman, "ada" tanpa "tidak" = blokir
                if "tidak" in status_text:
                    results[domain_text] = {"status": "AMAN", "raw": cols[1].text.strip()}
                elif "ada" in status_text:
                    results[domain_text] = {"status": "TERBLOKIR", "raw": cols[1].text.strip()}
                else:
                    results[domain_text] = {"status": "AMAN", "raw": cols[1].text.strip()}
        
        # Handle domains yang tidak muncul di hasil
        for d in domains:
            if d.lower() not in results:
                results[d.lower()] = {"status": "UNKNOWN", "raw": "Tidak ditemukan dalam hasil"}
        
        return results

    except Exception as e:
        logger.error(f"Error checking batch: {e}")
        logger.error(traceback.format_exc())
        for d in domains:
            if d.lower() not in results:
                results[d.lower()] = {"status": "ERROR", "raw": str(e)[:50]}
        return results

def bulk_cek_nawala(domains: list) -> list:
    """
    Legacy function - returns list of status strings
    Compatible with old code
    """
    if not domains:
        return ["⚠️ List domain kosong."]

    driver = None
    try:
        driver = init_driver()
        wait = WebDriverWait(driver, 30)
        
        all_results = {}
        
        # Process in batches of 5
        for i in range(0, len(domains), MAX_DOMAINS_PER_CHECK):
            batch = domains[i:i + MAX_DOMAINS_PER_CHECK]
            logger.info(f"Processing batch {i//MAX_DOMAINS_PER_CHECK + 1}: {batch}")
            
            batch_results = check_batch(driver, batch, wait)
            all_results.update(batch_results)
            
            # Delay between batches
            if i + MAX_DOMAINS_PER_CHECK < len(domains):
                time.sleep(3)
        
        # Format output
        hasil = []
        for domain in domains:
            info = all_results.get(domain.lower(), {"status": "UNKNOWN", "raw": ""})
            if info["status"] == "TERBLOKIR":
                hasil.append(f"🚫 {domain} TERBLOKIR")
            elif info["status"] == "AMAN":
                hasil.append(f"✅ {domain} AMAN")
            elif info["status"] == "ERROR":
                hasil.append(f"❌ {domain} ERROR: {info['raw']}")
            else:
                hasil.append(f"❓ {domain} UNKNOWN")
        
        return hasil

    except Exception as e:
        logger.error(traceback.format_exc())
        return [f"❌ Error: {str(e)[:50]}..."]
        
    finally:
        if driver:
            try:
                driver.quit()
            except:
                pass

def bulk_cek_nawala_with_info(domains_info: list) -> list:
    """
    Enhanced checker - accepts list of domain info dicts
    Input: [{"domain": "x.com", "group": "grp", "note": "note"}, ...]
    Returns: [{"domain": "x.com", "group": "grp", "note": "note", "status": "AMAN/TERBLOKIR"}, ...]
    """
    if not domains_info:
        return []

    driver = None
    try:
        driver = init_driver()
        wait = WebDriverWait(driver, 30)
        
        all_results = {}
        domains = [d["domain"] for d in domains_info]
        
        # Process in batches of 5
        for i in range(0, len(domains), MAX_DOMAINS_PER_CHECK):
            batch = domains[i:i + MAX_DOMAINS_PER_CHECK]
            logger.info(f"Processing batch {i//MAX_DOMAINS_PER_CHECK + 1}: {batch}")
            
            batch_results = check_batch(driver, batch, wait)
            all_results.update(batch_results)
            
            # Delay between batches
            if i + MAX_DOMAINS_PER_CHECK < len(domains):
                time.sleep(3)
        
        # Merge results with original info
        results = []
        for info in domains_info:
            domain = info["domain"].lower()
            check_result = all_results.get(domain, {"status": "UNKNOWN", "raw": ""})
            results.append({
                "domain": info["domain"],
                "group": info.get("group", "default"),
                "note": info.get("note", ""),
                "status": check_result["status"],
                "raw_status": check_result["raw"]
            })
        
        return results

    except Exception as e:
        logger.error(traceback.format_exc())
        # Return error status for all
        return [{
            "domain": d["domain"],
            "group": d.get("group", "default"),
            "note": d.get("note", ""),
            "status": "ERROR",
            "raw_status": str(e)[:50]
        } for d in domains_info]
        
    finally:
        if driver:
            try:
                driver.quit()
            except:
                pass

def cek_nawala_by_group(domains_info: list) -> dict:
    """
    Check domains grouped by priority
    Input: [{"domain": "x.com", "group": "grp", "note": "note"}, ...] - already sorted by priority
    Returns: {
        "group_name": [
            {"domain": "x.com", "note": "note", "status": "AMAN"},
            ...
        ],
        ...
    }
    """
    if not domains_info:
        return {}

    # Check all domains
    results = bulk_cek_nawala_with_info(domains_info)
    
    # Group results
    grouped = {}
    for r in results:
        group = r.get("group", "default")
        if group not in grouped:
            grouped[group] = []
        grouped[group].append({
            "domain": r["domain"],
            "note": r.get("note", ""),
            "status": r["status"],
            "raw_status": r.get("raw_status", "")
        })
    
    return grouped
