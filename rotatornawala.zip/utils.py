import json
import os

# =========================
# FILE OPERATIONS
# =========================

def read_list(filename):
    """Read simple list from file"""
    try:
        with open(filename, "r") as f:
            return list(set(i.strip().lower() for i in f if i.strip()))
    except FileNotFoundError:
        return []

def write_list(filename, items):
    """Write simple list to file"""
    with open(filename, "w") as f:
        f.write("\n".join(sorted(set(items))))

def read_json(filename, default=None):
    """Read JSON file with fallback"""
    if default is None:
        default = {}
    if not os.path.exists(filename):
        return default
    try:
        with open(filename, "r") as f:
            return json.load(f)
    except:
        return default

def write_json(filename, data):
    """Write JSON file with pretty formatting"""
    with open(filename, "w") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

# =========================
# DOMAIN DATA STRUCTURE
# =========================

def load_domains_data(filename):
    """Load domains data structure"""
    default = {
        "domains": {},
        "groups": {
            "default": {
                "priority": 99,
                "description": "Domain tanpa grup"
            }
        }
    }
    return read_json(filename, default)

def save_domains_data(filename, data):
    """Save domains data structure"""
    write_json(filename, data)

def add_domain(filename, domain, group="default", note=""):
    """Add domain with optional group and note"""
    from datetime import datetime
    data = load_domains_data(filename)
    
    domain = domain.strip().lower()
    
    if group not in data["groups"]:
        data["groups"][group] = {
            "priority": len(data["groups"]) + 1,
            "description": f"Grup {group}"
        }
    
    data["domains"][domain] = {
        "group": group,
        "note": note,
        "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    save_domains_data(filename, data)
    return True

def remove_domain(filename, domain):
    """Remove domain from data"""
    data = load_domains_data(filename)
    domain = domain.strip().lower()
    
    if domain in data["domains"]:
        del data["domains"][domain]
        save_domains_data(filename, data)
        return True
    return False

def get_all_domains(filename):
    """Get all domain names"""
    data = load_domains_data(filename)
    return list(data["domains"].keys())

def get_domain_info(filename, domain):
    """Get info for specific domain"""
    data = load_domains_data(filename)
    return data["domains"].get(domain.strip().lower())

def get_domains_by_group(filename, group):
    """Get all domains in a specific group"""
    data = load_domains_data(filename)
    return [d for d, info in data["domains"].items() if info.get("group") == group]

def get_groups_sorted(filename):
    """Get groups sorted by priority"""
    data = load_domains_data(filename)
    groups = data.get("groups", {})
    return sorted(groups.keys(), key=lambda g: groups[g].get("priority", 99))

def add_group(filename, group_name, priority=None, description=""):
    """Add or update a group"""
    data = load_domains_data(filename)
    
    if priority is None:
        priority = len(data["groups"]) + 1
    
    data["groups"][group_name] = {
        "priority": priority,
        "description": description or f"Grup {group_name}"
    }
    
    save_domains_data(filename, data)
    return True

def remove_group(filename, group_name):
    """Remove group and move domains to default"""
    if group_name == "default":
        return False
        
    data = load_domains_data(filename)
    
    if group_name in data["groups"]:
        for domain, info in data["domains"].items():
            if info.get("group") == group_name:
                info["group"] = "default"
        
        del data["groups"][group_name]
        save_domains_data(filename, data)
        return True
    return False

def set_group_priority(filename, group_name, priority):
    """Set priority for a group (lower = checked first)"""
    data = load_domains_data(filename)
    
    if group_name in data["groups"]:
        data["groups"][group_name]["priority"] = priority
        save_domains_data(filename, data)
        return True
    return False

def get_domains_ordered_by_priority(filename):
    """Get all domains ordered by group priority (for queue system)"""
    data = load_domains_data(filename)
    groups = get_groups_sorted(filename)
    
    ordered = []
    for group in groups:
        domains_in_group = get_domains_by_group(filename, group)
        for domain in sorted(domains_in_group):
            info = data["domains"].get(domain, {})
            ordered.append({
                "domain": domain,
                "group": group,
                "note": info.get("note", ""),
                "added_at": info.get("added_at", "")
            })
    
    return ordered

# =========================
# STOK GROUP SYSTEM
# =========================
# stok_data.json format:
# {
#     "groups": {
#         "jum": {
#             "description": "Stok domain JUM",
#             "domains": ["domain1.com", "domain2.com"]
#         },
#         "default": {
#             "description": "Stok umum",
#             "domains": ["generic1.com"]
#         }
#     }
# }

STOK_DEFAULT = {
    "groups": {
        "default": {
            "description": "Stok umum",
            "domains": []
        }
    }
}

def load_stok_data(filename):
    """Load stok data structure"""
    data = read_json(filename, STOK_DEFAULT)
    if "groups" not in data:
        data = STOK_DEFAULT.copy()
        data["groups"] = {"default": {"description": "Stok umum", "domains": []}}
    if "default" not in data["groups"]:
        data["groups"]["default"] = {"description": "Stok umum", "domains": []}
    return data

def save_stok_data(filename, data):
    """Save stok data structure"""
    write_json(filename, data)

def stok_add_group(filename, group_name, description=""):
    """Create a stok group"""
    data = load_stok_data(filename)
    if group_name not in data["groups"]:
        data["groups"][group_name] = {
            "description": description or f"Stok {group_name}",
            "domains": []
        }
        save_stok_data(filename, data)
    return True

def stok_remove_group(filename, group_name):
    """Remove stok group (moves remaining domains to default)"""
    if group_name == "default":
        return False
    data = load_stok_data(filename)
    if group_name in data["groups"]:
        remaining = data["groups"][group_name].get("domains", [])
        if remaining:
            data["groups"]["default"]["domains"].extend(remaining)
        del data["groups"][group_name]
        save_stok_data(filename, data)
        return True
    return False

def stok_list_groups(filename):
    """List all stok groups with counts"""
    data = load_stok_data(filename)
    result = {}
    for name, info in data["groups"].items():
        result[name] = {
            "description": info.get("description", ""),
            "count": len(info.get("domains", []))
        }
    return result

def stok_add_domains(filename, group_name, domains):
    """Add domains to a stok group. Returns (added, skipped)"""
    data = load_stok_data(filename)
    
    if group_name not in data["groups"]:
        data["groups"][group_name] = {
            "description": f"Stok {group_name}",
            "domains": []
        }
    
    current = data["groups"][group_name]["domains"]
    all_domains = set()
    for g_info in data["groups"].values():
        all_domains.update(g_info.get("domains", []))
    
    added = 0
    skipped = 0
    for d in domains:
        d = d.strip().lower()
        if d and d not in all_domains:
            current.append(d)
            all_domains.add(d)
            added += 1
        else:
            skipped += 1
    
    data["groups"][group_name]["domains"] = current
    save_stok_data(filename, data)
    return added, skipped

def stok_remove_domain(filename, domain, group_name=None):
    """Remove domain from stok. If group_name is None, search all groups."""
    data = load_stok_data(filename)
    domain = domain.strip().lower()
    
    if group_name:
        if group_name in data["groups"]:
            domains = data["groups"][group_name].get("domains", [])
            if domain in domains:
                domains.remove(domain)
                data["groups"][group_name]["domains"] = domains
                save_stok_data(filename, data)
                return True
        return False
    else:
        for g_name, g_info in data["groups"].items():
            domains = g_info.get("domains", [])
            if domain in domains:
                domains.remove(domain)
                g_info["domains"] = domains
                save_stok_data(filename, data)
                return True
        return False

def stok_get_domains(filename, group_name):
    """Get all domains in a stok group"""
    data = load_stok_data(filename)
    if group_name in data["groups"]:
        return list(data["groups"][group_name].get("domains", []))
    return []

def stok_ambil(filename, group_name):
    """Take one domain from stok group (FIFO). Returns domain or None.
    If specific group empty, fallback to default."""
    data = load_stok_data(filename)
    
    if group_name not in data["groups"]:
        group_name = "default"
    
    domains = data["groups"].get(group_name, {}).get("domains", [])
    
    if domains:
        domain = domains.pop(0)
        data["groups"][group_name]["domains"] = domains
        save_stok_data(filename, data)
        return domain
    
    # Fallback to default if specific group is empty
    if group_name != "default":
        default_domains = data["groups"].get("default", {}).get("domains", [])
        if default_domains:
            domain = default_domains.pop(0)
            data["groups"]["default"]["domains"] = default_domains
            save_stok_data(filename, data)
            return domain
    
    return None

def stok_peek(filename, group_name=None):
    """Check stok count. If group_name=None, return total across all groups."""
    data = load_stok_data(filename)
    
    if group_name:
        return len(data["groups"].get(group_name, {}).get("domains", []))
    else:
        total = 0
        for g_info in data["groups"].values():
            total += len(g_info.get("domains", []))
        return total

def stok_peek_all(filename):
    """Return dict of {group_name: count} for all groups"""
    data = load_stok_data(filename)
    result = {}
    for name, info in data["groups"].items():
        result[name] = len(info.get("domains", []))
    return result

def stok_return_domain(filename, group_name, domain):
    """Return a domain back to stok (e.g. when update fails)"""
    data = load_stok_data(filename)
    if group_name not in data["groups"]:
        group_name = "default"
    domains = data["groups"].get(group_name, {}).get("domains", [])
    if domain not in domains:
        domains.append(domain)
        data["groups"][group_name]["domains"] = domains
        save_stok_data(filename, data)

def migrate_stok_txt_to_json(stok_txt_file, stok_json_file):
    """Migrate old stok.txt to new stok_data.json format. Call once."""
    old_domains = read_list(stok_txt_file)
    if not old_domains:
        return 0
    
    data = load_stok_data(stok_json_file)
    current_default = set(data["groups"].get("default", {}).get("domains", []))
    added = 0
    for d in old_domains:
        if d not in current_default:
            data["groups"]["default"]["domains"].append(d)
            current_default.add(d)
            added += 1
    
    save_stok_data(stok_json_file, data)
    return added
